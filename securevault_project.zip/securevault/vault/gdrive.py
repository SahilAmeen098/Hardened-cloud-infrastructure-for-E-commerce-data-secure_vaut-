"""
Google Drive Integration Module for SecureVault
Uploads encrypted .vault files to Google Drive using a Service Account.

Setup Steps:
1. Go to https://console.cloud.google.com/
2. Create a new project
3. Enable "Google Drive API"
4. Create a Service Account → download credentials.json
5. Share your target Google Drive folder with the service account email
6. Set GDRIVE_CREDENTIALS_PATH and GDRIVE_FOLDER_ID in settings.py
"""

import io
import os

# Google Drive API imports
# pip install google-api-python-client google-auth google-auth-httplib2
try:
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaIoBaseUpload
    from google.oauth2 import service_account
    GDRIVE_AVAILABLE = True
except ImportError:
    GDRIVE_AVAILABLE = False

from django.conf import settings


SCOPES = ['https://www.googleapis.com/auth/drive.file']


def get_drive_service():
    """
    Authenticate with Google Drive API using Service Account credentials.
    Returns a Drive API service object.
    """
    if not GDRIVE_AVAILABLE:
        raise ImportError(
            "Google API libraries not installed. "
            "Run: pip install google-api-python-client google-auth google-auth-httplib2"
        )

    credentials_path = getattr(settings, 'GDRIVE_CREDENTIALS_PATH', None)

    if not credentials_path or not os.path.exists(credentials_path):
        raise FileNotFoundError(
            f"Google Drive credentials file not found at: {credentials_path}\n"
            "Please download your service account credentials.json from Google Cloud Console "
            "and set GDRIVE_CREDENTIALS_PATH in settings.py"
        )

    credentials = service_account.Credentials.from_service_account_file(
        credentials_path,
        scopes=SCOPES
    )

    service = build('drive', 'v3', credentials=credentials)
    return service


def upload_encrypted_file(encrypted_bytes: bytes, filename: str, original_filename: str) -> dict:
    """
    Upload an encrypted .vault file to Google Drive.

    Args:
        encrypted_bytes: The encrypted file content as bytes
        filename: The name to save on Google Drive (e.g. enc_123_report.pdf.vault)
        original_filename: The original file name for metadata

    Returns:
        dict with keys: file_id, file_name, web_link, size
    """
    service = get_drive_service()
    folder_id = getattr(settings, 'GDRIVE_FOLDER_ID', None)

    # File metadata
    file_metadata = {
        'name': filename,
        'description': f'SecureVault encrypted file | Original: {original_filename} | AES-256-GCM',
    }

    # If folder ID is specified, upload into that folder
    if folder_id:
        file_metadata['parents'] = [folder_id]

    # Create a media upload object from bytes
    media = MediaIoBaseUpload(
        io.BytesIO(encrypted_bytes),
        mimetype='application/octet-stream',
        resumable=False
    )

    # Upload the file
    uploaded = service.files().create(
        body=file_metadata,
        media_body=media,
        fields='id, name, size, webViewLink, webContentLink'
    ).execute()

    return {
        'file_id': uploaded.get('id'),
        'file_name': uploaded.get('name'),
        'web_link': uploaded.get('webViewLink', ''),
        'download_link': uploaded.get('webContentLink', ''),
        'size': uploaded.get('size', 0),
    }


def download_encrypted_file(file_id: str) -> bytes:
    """
    Download an encrypted file from Google Drive by file ID.

    Args:
        file_id: The Google Drive file ID

    Returns:
        bytes: The raw encrypted file content
    """
    service = get_drive_service()

    request = service.files().get_media(fileId=file_id)
    file_buffer = io.BytesIO()

    # Download in chunks
    from googleapiclient.http import MediaIoBaseDownload
    downloader = MediaIoBaseDownload(file_buffer, request)

    done = False
    while not done:
        _, done = downloader.next_chunk()

    file_buffer.seek(0)
    return file_buffer.read()


def delete_drive_file(file_id: str) -> bool:
    """
    Permanently delete a file from Google Drive.

    Args:
        file_id: The Google Drive file ID

    Returns:
        bool: True if deleted successfully
    """
    try:
        service = get_drive_service()
        service.files().delete(fileId=file_id).execute()
        return True
    except Exception:
        return False


def list_vault_files(folder_id: str = None) -> list:
    """
    List all .vault files in the configured Google Drive folder.

    Returns:
        list of file metadata dicts
    """
    service = get_drive_service()

    query = "name contains '.vault' and trashed=false"
    if folder_id:
        query += f" and '{folder_id}' in parents"

    results = service.files().list(
        q=query,
        fields="files(id, name, size, createdTime, webViewLink)"
    ).execute()

    return results.get('files', [])


def is_gdrive_configured() -> bool:
    """Check if Google Drive is properly configured."""
    credentials_path = getattr(settings, 'GDRIVE_CREDENTIALS_PATH', None)
    return (
        GDRIVE_AVAILABLE and
        credentials_path is not None and
        os.path.exists(str(credentials_path))
    )
