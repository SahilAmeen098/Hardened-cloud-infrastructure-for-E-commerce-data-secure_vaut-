from django.db import models
from django.contrib.auth.models import User


class EncryptedFile(models.Model):
    FILE_TYPES = [
        ('invoice', 'Invoice'),
        ('customer_data', 'Customer Data'),
        ('payment_info', 'Payment Info'),
        ('contract', 'Contract'),
        ('report', 'Report'),
        ('other', 'Other'),
    ]

    STORAGE_LOCAL = 'local'
    STORAGE_GDRIVE = 'gdrive'
    STORAGE_CHOICES = [
        (STORAGE_LOCAL, 'Local Server'),
        (STORAGE_GDRIVE, 'Google Drive'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='files')
    original_filename = models.CharField(max_length=255)
    encrypted_file = models.FileField(upload_to='encrypted/', blank=True, null=True)
    file_type = models.CharField(max_length=50, choices=FILE_TYPES, default='other')
    file_size = models.PositiveBigIntegerField(default=0)  # in bytes
    encryption_algorithm = models.CharField(max_length=50, default='AES-256-GCM')
    salt = models.BinaryField(max_length=32)
    nonce = models.BinaryField(max_length=16)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    description = models.TextField(blank=True)
    download_count = models.PositiveIntegerField(default=0)

    # Google Drive fields
    storage_backend = models.CharField(max_length=20, choices=STORAGE_CHOICES, default=STORAGE_LOCAL)
    gdrive_file_id = models.CharField(max_length=255, blank=True, null=True)
    gdrive_web_link = models.URLField(blank=True, null=True)

    class Meta:
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"{self.original_filename} ({self.user.username})"

    def is_on_gdrive(self):
        return self.storage_backend == self.STORAGE_GDRIVE and self.gdrive_file_id

    def get_file_size_display(self):
        size = self.file_size
        if size < 1024:
            return f"{size} B"
        elif size < 1024 ** 2:
            return f"{size / 1024:.1f} KB"
        elif size < 1024 ** 3:
            return f"{size / 1024 ** 2:.1f} MB"
        return f"{size / 1024 ** 3:.1f} GB"


class AuditLog(models.Model):
    ACTION_CHOICES = [
        ('upload', 'File Uploaded'),
        ('gdrive_upload', 'Uploaded to Google Drive'),
        ('gdrive_download', 'Downloaded from Google Drive'),
        ('download', 'File Downloaded'),
        ('delete', 'File Deleted'),
        ('login', 'User Login'),
        ('logout', 'User Logout'),
        ('register', 'User Registered'),
        ('failed_decrypt', 'Decryption Failed'),
    ]

    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    action = models.CharField(max_length=50, choices=ACTION_CHOICES)
    file = models.ForeignKey(EncryptedFile, on_delete=models.SET_NULL, null=True, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    details = models.TextField(blank=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.user} - {self.action} at {self.timestamp}"
