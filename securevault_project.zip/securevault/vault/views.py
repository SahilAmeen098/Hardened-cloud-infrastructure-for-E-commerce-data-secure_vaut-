import os
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse
from django.core.files.base import ContentFile
from django.db.models import Sum, Count
from cryptography.exceptions import InvalidTag

from .models import EncryptedFile, AuditLog
from .forms import RegisterForm, LoginForm, FileUploadForm, FileDecryptForm
from .encryption import encrypt_file_to_bytes, decrypt_file_from_bytes, get_encryption_info
from .gdrive import upload_encrypted_file, download_encrypted_file, delete_drive_file, is_gdrive_configured


def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        return x_forwarded_for.split(',')[0]
    return request.META.get('REMOTE_ADDR')


def log_action(user, action, file=None, request=None, details=''):
    ip = get_client_ip(request) if request else None
    AuditLog.objects.create(user=user, action=action, file=file, ip_address=ip, details=details)


def index(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return redirect('login')


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            log_action(user, 'register', request=request, details='New user registered')
            messages.success(request, f'Welcome to SecureVault, {user.first_name}!')
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'vault/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            log_action(user, 'login', request=request, details='Successful login')
            messages.success(request, f'Welcome back, {user.first_name or user.username}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid credentials. Please try again.')
    else:
        form = LoginForm()
    return render(request, 'vault/login.html', {'form': form})


@login_required
def logout_view(request):
    log_action(request.user, 'logout', request=request)
    logout(request)
    messages.info(request, 'You have been securely logged out.')
    return redirect('login')


@login_required
def dashboard(request):
    files = EncryptedFile.objects.filter(user=request.user)
    recent_logs = AuditLog.objects.filter(user=request.user)[:10]
    stats = {
        'total_files': files.count(),
        'total_size': files.aggregate(s=Sum('file_size'))['s'] or 0,
        'total_downloads': files.aggregate(d=Sum('download_count'))['d'] or 0,
        'gdrive_files': files.filter(storage_backend='gdrive').count(),
        'local_files': files.filter(storage_backend='local').count(),
    }
    size = stats['total_size']
    if size < 1024:
        stats['total_size_display'] = f"{size} B"
    elif size < 1024 ** 2:
        stats['total_size_display'] = f"{size / 1024:.1f} KB"
    else:
        stats['total_size_display'] = f"{size / 1024 ** 2:.1f} MB"

    context = {
        'files': files,
        'stats': stats,
        'recent_logs': recent_logs,
        'encryption_info': get_encryption_info(),
        'gdrive_configured': is_gdrive_configured(),
    }
    return render(request, 'vault/dashboard.html', context)


@login_required
def upload_file(request):
    gdrive_ready = is_gdrive_configured()

    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = request.FILES['file']
            password = form.cleaned_data['encryption_password']
            use_gdrive = request.POST.get('use_gdrive') == 'on' and gdrive_ready

            try:
                file_data = uploaded_file.read()
                file_size = len(file_data)

                # ── STEP 1: Encrypt with AES-256-GCM ─────────────────────
                packed_data, salt, nonce = encrypt_file_to_bytes(file_data, password)
                encrypted_filename = f"enc_{request.user.id}_{uploaded_file.name}.vault"

                enc_file = form.save(commit=False)
                enc_file.user = request.user
                enc_file.original_filename = uploaded_file.name
                enc_file.file_size = file_size
                enc_file.salt = salt
                enc_file.nonce = nonce

                if use_gdrive:
                    # ── STEP 2: Upload encrypted blob to Google Drive ─────
                    gdrive_result = upload_encrypted_file(
                        encrypted_bytes=packed_data,
                        filename=encrypted_filename,
                        original_filename=uploaded_file.name,
                    )
                    enc_file.storage_backend = EncryptedFile.STORAGE_GDRIVE
                    enc_file.gdrive_file_id = gdrive_result['file_id']
                    enc_file.gdrive_web_link = gdrive_result['web_link']
                    enc_file.save()

                    log_action(request.user, 'upload', file=enc_file, request=request,
                               details=f'Encrypted {uploaded_file.name} ({file_size} bytes)')
                    log_action(request.user, 'gdrive_upload', file=enc_file, request=request,
                               details=f'Uploaded to Google Drive. ID: {gdrive_result["file_id"]}')

                    messages.success(request,
                        f'✓ "{uploaded_file.name}" encrypted with AES-256-GCM and sent to Google Drive ☁️')
                else:
                    # ── STEP 2 (alt): Save locally ────────────────────────
                    enc_file.storage_backend = EncryptedFile.STORAGE_LOCAL
                    enc_file.encrypted_file.save(encrypted_filename, ContentFile(packed_data))
                    enc_file.save()
                    log_action(request.user, 'upload', file=enc_file, request=request,
                               details=f'Encrypted {uploaded_file.name} — local storage')
                    messages.success(request,
                        f'✓ "{uploaded_file.name}" encrypted with AES-256-GCM and stored locally.')

                return redirect('dashboard')

            except Exception as e:
                messages.error(request, f'Operation failed: {str(e)}')
    else:
        form = FileUploadForm()

    return render(request, 'vault/upload.html', {
        'form': form,
        'gdrive_configured': gdrive_ready,
    })


@login_required
def download_file(request, file_id):
    enc_file = get_object_or_404(EncryptedFile, id=file_id, user=request.user)

    if request.method == 'POST':
        form = FileDecryptForm(request.POST)
        if form.is_valid():
            password = form.cleaned_data['encryption_password']
            try:
                # ── Fetch from correct storage backend ────────────────────
                if enc_file.is_on_gdrive():
                    packed_data = download_encrypted_file(enc_file.gdrive_file_id)
                    log_action(request.user, 'gdrive_download', file=enc_file, request=request,
                               details=f'Fetched from Google Drive: {enc_file.original_filename}')
                else:
                    enc_file.encrypted_file.open('rb')
                    packed_data = enc_file.encrypted_file.read()
                    enc_file.encrypted_file.close()

                # ── Decrypt ───────────────────────────────────────────────
                plaintext = decrypt_file_from_bytes(packed_data, password)

                enc_file.download_count += 1
                enc_file.save(update_fields=['download_count'])
                log_action(request.user, 'download', file=enc_file, request=request,
                           details=f'Successfully decrypted {enc_file.original_filename}')

                response = HttpResponse(plaintext, content_type='application/octet-stream')
                response['Content-Disposition'] = f'attachment; filename="{enc_file.original_filename}"'
                response['Content-Length'] = len(plaintext)
                return response

            except InvalidTag:
                log_action(request.user, 'failed_decrypt', file=enc_file, request=request,
                           details=f'Wrong password for {enc_file.original_filename}')
                messages.error(request, '✗ Wrong password or corrupted file. Decryption failed.')
            except Exception as e:
                messages.error(request, f'Error: {str(e)}')
    else:
        form = FileDecryptForm()

    return render(request, 'vault/download.html', {'form': form, 'file': enc_file})


@login_required
def delete_file(request, file_id):
    enc_file = get_object_or_404(EncryptedFile, id=file_id, user=request.user)

    if request.method == 'POST':
        filename = enc_file.original_filename
        if enc_file.is_on_gdrive():
            delete_drive_file(enc_file.gdrive_file_id)
        elif enc_file.encrypted_file:
            try:
                enc_file.encrypted_file.delete(save=False)
            except Exception:
                pass

        log_action(request.user, 'delete', request=request,
                   details=f'Deleted {filename} from {enc_file.storage_backend}')
        enc_file.delete()
        messages.success(request, f'"{filename}" permanently deleted.')
        return redirect('dashboard')

    return render(request, 'vault/confirm_delete.html', {'file': enc_file})


@login_required
def audit_log(request):
    logs = AuditLog.objects.filter(user=request.user)
    return render(request, 'vault/audit_log.html', {'logs': logs})
