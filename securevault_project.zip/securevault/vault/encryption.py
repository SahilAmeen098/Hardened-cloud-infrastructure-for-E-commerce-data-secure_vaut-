"""
AES-256-GCM Encryption Module for SecureVault E-Commerce Platform
Implements industry-standard encryption for data-at-rest protection.
"""
import os
import struct
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidTag
import base64


# Constants
SALT_SIZE = 32        # 256-bit salt
NONCE_SIZE = 12       # 96-bit nonce (recommended for GCM)
KEY_SIZE = 32         # 256-bit AES key
PBKDF2_ITERATIONS = 480000  # OWASP recommended minimum (2023)
CHUNK_SIZE = 64 * 1024      # 64KB chunks for large file support


def derive_key(password: str, salt: bytes) -> bytes:
    """
    Derive a 256-bit encryption key from a password using PBKDF2-HMAC-SHA256.
    This is a key stretching function that makes brute-force attacks expensive.
    """
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_SIZE,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    return kdf.derive(password.encode('utf-8'))


def encrypt_file(file_data: bytes, password: str) -> tuple[bytes, bytes, bytes]:
    """
    Encrypt file data using AES-256-GCM.

    AES-GCM provides both:
    - Confidentiality (encryption)
    - Integrity/Authenticity (authentication tag)

    Returns:
        tuple: (encrypted_data, salt, nonce)
    """
    # Generate cryptographically secure random salt and nonce
    salt = os.urandom(SALT_SIZE)
    nonce = os.urandom(NONCE_SIZE)

    # Derive encryption key from password
    key = derive_key(password, salt)

    # Encrypt with AES-256-GCM (includes authentication tag automatically)
    aesgcm = AESGCM(key)
    encrypted_data = aesgcm.encrypt(nonce, file_data, None)

    return encrypted_data, salt, nonce


def decrypt_file(encrypted_data: bytes, password: str, salt: bytes, nonce: bytes) -> bytes:
    """
    Decrypt file data using AES-256-GCM.

    The GCM mode automatically verifies the authentication tag,
    raising InvalidTag if the data was tampered with or wrong password.

    Returns:
        bytes: Original plaintext file data

    Raises:
        InvalidTag: If password is wrong or data is corrupted/tampered
    """
    # Re-derive the same key from password + salt
    key = derive_key(password, salt)

    # Decrypt and verify authentication tag
    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(nonce, encrypted_data, None)

    return plaintext


def encrypt_file_to_bytes(file_data: bytes, password: str) -> bytes:
    """
    Encrypt and pack everything into a single bytes object with a header.
    Format: [MAGIC(8)] [SALT(32)] [NONCE(12)] [CIPHERTEXT(...)]
    """
    MAGIC = b'SVAULT01'  # SecureVault format identifier

    encrypted_data, salt, nonce = encrypt_file(file_data, password)

    # Pack into single blob: magic + salt + nonce + ciphertext
    packed = MAGIC + salt + nonce + encrypted_data
    return packed, salt, nonce


def decrypt_file_from_bytes(packed_data: bytes, password: str) -> bytes:
    """
    Unpack and decrypt a file blob created by encrypt_file_to_bytes.
    """
    MAGIC = b'SVAULT01'
    MAGIC_SIZE = 8

    if not packed_data.startswith(MAGIC):
        raise ValueError("Invalid file format or corrupted file.")

    offset = MAGIC_SIZE
    salt = packed_data[offset:offset + SALT_SIZE]
    offset += SALT_SIZE
    nonce = packed_data[offset:offset + NONCE_SIZE]
    offset += NONCE_SIZE
    encrypted_data = packed_data[offset:]

    return decrypt_file(encrypted_data, password, salt, nonce)


def get_encryption_info() -> dict:
    """Return metadata about the encryption configuration."""
    return {
        'algorithm': 'AES-256-GCM',
        'key_size': f'{KEY_SIZE * 8} bits',
        'kdf': 'PBKDF2-HMAC-SHA256',
        'iterations': PBKDF2_ITERATIONS,
        'salt_size': f'{SALT_SIZE * 8} bits',
        'nonce_size': f'{NONCE_SIZE * 8} bits',
        'authenticated': True,
    }
