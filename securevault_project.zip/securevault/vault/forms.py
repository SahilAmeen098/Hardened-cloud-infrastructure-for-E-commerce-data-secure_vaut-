from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from .models import EncryptedFile


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={
        'placeholder': 'your@email.com',
        'autocomplete': 'email',
    }))
    first_name = forms.CharField(max_length=50, required=True, widget=forms.TextInput(attrs={
        'placeholder': 'First Name',
    }))
    last_name = forms.CharField(max_length=50, required=True, widget=forms.TextInput(attrs={
        'placeholder': 'Last Name',
    }))

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']
        widgets = {
            'username': forms.TextInput(attrs={'placeholder': 'Choose a username'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs['placeholder'] = 'Create password'
        self.fields['password2'].widget.attrs['placeholder'] = 'Confirm password'
        for field in self.fields.values():
            field.widget.attrs['class'] = 'form-input'

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        if commit:
            user.save()
        return user


class LoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({
            'placeholder': 'Username',
            'class': 'form-input',
        })
        self.fields['password'].widget.attrs.update({
            'placeholder': 'Password',
            'class': 'form-input',
        })


class FileUploadForm(forms.ModelForm):
    encryption_password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Strong encryption password',
            'class': 'form-input',
            'autocomplete': 'new-password',
        }),
        help_text='This password encrypts your file with AES-256-GCM. Store it safely — it cannot be recovered.'
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Confirm encryption password',
            'class': 'form-input',
        })
    )
    file = forms.FileField(widget=forms.FileInput(attrs={
        'class': 'file-input',
        'accept': '*/*',
    }))

    class Meta:
        model = EncryptedFile
        fields = ['file_type', 'description']
        widgets = {
            'file_type': forms.Select(attrs={'class': 'form-input'}),
            'description': forms.Textarea(attrs={
                'class': 'form-input',
                'rows': 3,
                'placeholder': 'Optional description for this file...',
            }),
        }

    def clean(self):
        cleaned_data = super().clean()
        pw1 = cleaned_data.get('encryption_password')
        pw2 = cleaned_data.get('confirm_password')
        if pw1 and pw2 and pw1 != pw2:
            raise forms.ValidationError('Encryption passwords do not match.')
        if pw1 and len(pw1) < 8:
            raise forms.ValidationError('Encryption password must be at least 8 characters.')
        return cleaned_data


class FileDecryptForm(forms.Form):
    encryption_password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Enter your encryption password',
            'class': 'form-input',
            'autofocus': True,
        }),
        label='Encryption Password'
    )
