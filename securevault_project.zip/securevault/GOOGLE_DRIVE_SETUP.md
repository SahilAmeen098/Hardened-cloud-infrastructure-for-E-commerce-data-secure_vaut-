# ☁️ Google Drive Integration — Setup Guide

Follow these steps to connect SecureVault to Google Drive so encrypted files
are automatically uploaded to the cloud after encryption.

---

## Step 1 — Create a Google Cloud Project

1. Go to → https://console.cloud.google.com/
2. Click **"New Project"**
3. Name it: `SecureVault` → Click **Create**

---

## Step 2 — Enable Google Drive API

1. In your project, go to **APIs & Services → Library**
2. Search for **"Google Drive API"**
3. Click on it → Click **"Enable"**

---

## Step 3 — Create a Service Account

1. Go to **APIs & Services → Credentials**
2. Click **"+ Create Credentials" → Service Account**
3. Name: `securevault-service` → Click **Create and Continue**
4. Role: Select **"Editor"** → Click **Continue → Done**

---

## Step 4 — Download the credentials.json Key

1. On the Credentials page, click your new service account
2. Go to the **"Keys"** tab
3. Click **"Add Key" → Create new key → JSON**
4. A `credentials.json` file will download automatically
5. **Place this file in your project root:**
   ```
   securevault/
   ├── credentials.json   ← PUT IT HERE
   ├── manage.py
   └── ...
   ```

---

## Step 5 — Share a Google Drive Folder

1. Open **Google Drive** (drive.google.com)
2. Create a new folder, e.g. `SecureVault Encrypted Files`
3. Right-click the folder → **Share**
4. Copy your service account email (looks like `securevault-service@your-project.iam.gserviceaccount.com`)
5. Paste it in the share box → Set role to **"Editor"** → Click **Send**

---

## Step 6 — Get the Folder ID

1. Open the folder in Google Drive
2. Look at the URL:
   ```
   https://drive.google.com/drive/folders/1ABC123XYZfolderId
   ```
3. Copy the ID after `/folders/` → e.g. `1ABC123XYZfolderId`

---

## Step 7 — Update settings.py

Open `securevault/securevault/settings.py` and fill in:

```python
GDRIVE_CREDENTIALS_PATH = BASE_DIR / 'credentials.json'
GDRIVE_FOLDER_ID = '1ABC123XYZfolderId'   # ← Your folder ID here
```

---

## Step 8 — Install Google API Libraries

```bash
pip install -r requirements.txt
```

This installs:
- `google-api-python-client`
- `google-auth`
- `google-auth-httplib2`

---

## Step 9 — Run Migrations & Start

```bash
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

---

## ✅ You're Done!

When you go to **Encrypt File**, you'll now see:

```
☁️ Upload to Google Drive   [CONNECTED ✓]
```

Check the box → your encrypted `.vault` file will be:
1. AES-256-GCM encrypted on your server (password never leaves)
2. Uploaded to Google Drive via the API
3. Even if someone hacks the Drive — they see only gibberish 🔐

---

## How the Workflow Works

```
Your File (customer_orders.csv)
        ↓
[ AES-256-GCM Encryption ]  ← Python cryptography library
        ↓
  encrypted.vault blob
        ↓
[ Google Drive API Upload ]  ← google-api-python-client
        ↓
  Stored in Drive Folder
  (useless without password)
```

This is exactly what your sir described as:
> "Your Python code logs into a service account, carries the locked box
>  across the internet, and places it into a specific Google Drive folder."
